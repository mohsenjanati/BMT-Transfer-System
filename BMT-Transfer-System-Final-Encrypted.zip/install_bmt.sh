#!/bin/bash

echo "🔐 Welcome to BMT Transfer System Installer"
echo -n "Enter installation password: "
read -s PASSWORD
echo

if [ "$PASSWORD" != "0698798" ]; then
    echo "❌ Incorrect password. Installation aborted."
    exit 1
fi

echo "✅ Password accepted. Proceeding with installation..."

# Unzip the embedded archive
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
UNZIP_DIR="$SCRIPT_DIR/BMT_Installed"
mkdir -p "$UNZIP_DIR"
unzip -q "$SCRIPT_DIR/hidden_bmt.zip" -d "$UNZIP_DIR"

# Run the main script
chmod +x "$UNZIP_DIR/banking_transfer_money.sh"
"$UNZIP_DIR/banking_transfer_money.sh"
