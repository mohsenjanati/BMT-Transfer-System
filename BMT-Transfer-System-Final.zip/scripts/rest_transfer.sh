#!/bin/bash
echo 'REST transfer script...'