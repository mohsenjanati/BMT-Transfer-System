#!/bin/bash
echo 'SOAP transfer script...'