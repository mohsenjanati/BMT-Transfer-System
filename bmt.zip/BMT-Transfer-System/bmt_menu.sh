#!/bin/bash
# Main menu script for BMT transfer system