#!/bin/bash
# REST/JSON-based bank transfer logic