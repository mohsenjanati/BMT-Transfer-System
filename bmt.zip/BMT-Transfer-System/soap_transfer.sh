#!/bin/bash
# SOAP-based bank transfer logic