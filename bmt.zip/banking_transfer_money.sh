#!/bin/bash
echo "🏦 Welcome to BMT - Main Menu"
# Placeholder main menu