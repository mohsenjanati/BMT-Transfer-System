#!/bin/bash
echo "Blockchain Transfer initiated"