#!/bin/bash
echo "Installing BMT..."