#!/bin/bash
echo "ISO 20022 Transfer initiated"