#!/bin/bash
echo "Open Banking Transfer initiated"