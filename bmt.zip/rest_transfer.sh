#!/bin/bash
echo "REST Transfer initiated"