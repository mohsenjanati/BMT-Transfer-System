#!/bin/bash
echo "SEPA/ACH Transfer initiated"