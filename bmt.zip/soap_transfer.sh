#!/bin/bash
echo "SOAP Transfer initiated"