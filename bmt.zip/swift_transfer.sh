#!/bin/bash
echo "SWIFT/MT Transfer initiated"