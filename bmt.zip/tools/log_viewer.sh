#!/bin/bash
echo "Viewing logs..."