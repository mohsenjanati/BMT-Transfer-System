#!/bin/bash
echo "Scanning ports..."